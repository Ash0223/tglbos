package com.tg.bos.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "accounts")
@Inheritance(strategy = InheritanceType.JOINED)
@Data // Generates getters, setters, equals, hashCode, toString
@NoArgsConstructor
@AllArgsConstructor
public abstract class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String accountNumber; // Instance-specific account number

//    @Transient
//    private static int accountCounter = 1000; // Counter for generating unique account numbers

    @Column(name = "name", nullable = false)
    @NotNull(message = "Account name cannot be null")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "Account name must only contain alphabets")
    private String name;

    
    @ManyToOne
    @JoinColumn(name = "privilege_id")
    private Privilege privilege;

    
    @Column(name = "pin_number", nullable = false)
    @NotNull(message = "PIN cannot be null")
    @Size(min = 4, max = 4, message = "PIN must be exactly 4 digits")
    @Pattern(regexp = "^[0-9]{4}$", message = "PIN must be a 4-digit number")
    private int pinNumber;

    
    @Column(name = "balance", nullable = false)
    @Min(value = 0, message = "Balance cannot be negative")
    private double balance;

    
    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "activated_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Date format specification
    private LocalDate activatedDate;

    @Column(name = "closed_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Date format specification
    private LocalDate closedDate;

}
