package com.tg.bos.entity;

import jakarta.persistence.*;

/**
 * Represents different privilege levels for accounts.
 */
public enum Privilege {
    SILVER, GOLD, PREMIUM
}
