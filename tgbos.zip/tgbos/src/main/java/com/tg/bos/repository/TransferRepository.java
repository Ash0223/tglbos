package com.tg.bos.repository;


import com.tg.bos.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransferRepository extends JpaRepository<Transfer, Long> {
    // No custom queries for now, only the default CRUD operations
}
