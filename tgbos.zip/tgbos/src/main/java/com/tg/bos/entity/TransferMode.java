package com.tg.bos.entity;


/**
 * Represents different modes of money transfer.
 */
public enum TransferMode {
    IMPS, RTGS, NEFT
}
