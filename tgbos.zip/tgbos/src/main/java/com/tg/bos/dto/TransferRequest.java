package com.tg.bos.dto;

import com.tg.bos.entity.Account;
import com.tg.bos.entity.TransferMode;
import lombok.Data;

@Data  // Lombok annotation to generate getters, setters, toString, equals, hashCode
public class TransferRequest {

    private Account fromAccount;
    private Account toAccount;
    private double amount;
    private TransferMode transferMode;

    
    private Long fromAccountNumber; // Sender's account number
    private Long toAccountNumber;   // Receiver's account number
//    private double amount;          // Transfer amount
//    private String transferMode;    // Mode of transfer (e.g., IMPS, RTGS)

    // Getters and Setters
    public Long getFromAccountNumber() {
        return fromAccountNumber;
    }

    public void setFromAccountNumber(Long fromAccountNumber) {
        this.fromAccountNumber = fromAccountNumber;
    }

    public Long getToAccountNumber() {
        return toAccountNumber;
    }

    public void setToAccountNumber(Long toAccountNumber) {
        this.toAccountNumber = toAccountNumber;
    }

}
